/* 
 * Activity 1.1.5
 */
public class Main {
  public static void main(String[] args) {

    // theplanets.org average distance from earth to the planets
    int mercury = 56974146;
    int venus = 25724767;
    int mars = 48678219;
    int jupiter = 390674710;
    int saturn = 792248270;

    // number of planets to visit
    int numPlanets = 5;

    // speed of light and our speed
    int lightSpeed = 670616629;
    lightSpeed /= 10;

    // total travel time
    double total = 0;

    // Widening Version (Soliday's codes)

    // I finished it so you can turn it in once we are done.But I think you still
    // need to do the average. I texted the phonenumber you gave me.

    // Mercury Travel Time
    System.out.println("Soliday's codes");
    System.out.println("Widening Version Outputs");
    double MercuryCalc = mercury;
    MercuryCalc /= lightSpeed;
    System.out.println("Traveling time to Mercury: " + MercuryCalc + " hours.");

    // Venus Travel Time

    double VenusCalc = venus;
    VenusCalc /= lightSpeed;
    System.out.println("Traveling time to Venus: " + VenusCalc + " hours.");

    // Mars Travel Time
    double MarsCalc = mars;
    MarsCalc /= lightSpeed;
    System.out.println("Traveling time to MarsCal: " + MarsCalc + " hours.");

    // Jupiter Travel Time
    double JupiterCalc = jupiter;
    JupiterCalc /= lightSpeed;
    System.out.println("Traveling time to Jupiter: " + JupiterCalc + " hours.");

    // Saturn Travel Time
    double SaturnCalc = saturn;
    SaturnCalc /= lightSpeed;
    System.out.println("Traveling time to Saturn: " + SaturnCalc + " hours.");

    // Casting Version (James codes)
   

    // My variables will be capatalized so the work can go along side Soliday.
    int Mercury = 56974146;
    int Venus = 25724767;
    int Mars = 48678219;
    int Jupiter = 390674710;
    int Saturn = 792248270;

    // number of planets to visit
    int NumPlanets = 5;

    // speed of light and our speed
    int LightSpeed = 670616629;
    LightSpeed /= 10;

    // total travel time
    double Total = 0;

    // This will be mercury's time
    Total += Mercury / (double) LightSpeed;
    System.out
        .println("Travel time to mercury: " + Mercury / (double) LightSpeed + " hours. I have visited 1 out of the"
            + NumPlanets + "planets. My total time right now is " + Total + "hours.");

    // This is venus's time
    Total += Venus / (double) LightSpeed;
    System.out.println("Travel time to venus: " + Venus / (double) LightSpeed + " hours. I have visited 2 out of the "
        + NumPlanets + " planets. My total time right now is " + Total + "hours.");

    // mars time
    Total += Mars / (double) LightSpeed;
    System.out.println("Travel time to mars: " + Mars / (double) LightSpeed + " hours. I have visited 3 out of the "
        + NumPlanets + " planets. My total time right now is " + Total + "hours.");

    // The time it will take to get to jupiter
    Total += Jupiter / (double) LightSpeed;
    System.out
        .println("Travel time to jupiter: " + Jupiter / (double) LightSpeed + " hours. I have visited 4 out of the "
            + NumPlanets + " planets. My total time right now is " + Total + "hours.");

    // the time it will take to reach Saturn
    Total += Saturn / (double) LightSpeed;
    System.out.println("Travel time to saturn: " + Saturn / (double) LightSpeed + " hours. I have visited all of the "
        + NumPlanets + " planets. My total time right now is " + Total + "hours.");

    // calculating the average. I am not sure if we were supposed to add a Average
    // variable, so I just did calculations in the statment. Tis is to make it a int
    // value
    System.out.println("The average time between each planet is " + ((int) Total / NumPlanets) + " hours.");

    // This is to make the average a double value
    System.out.println("The average time between each planet is " + (Total / (double) NumPlanets) + " hours.");

    // this is with x + .5
    System.out.println("The average time between each planet is " + ((int) (Total / NumPlanets + .5)) + " hours.");

    // By James and Soliday
  }
}